﻿//public variable

public var speed :int = 6;

//function called once when the bullet is created

function Start () {

	//get rigidbody component
	var r2d = GetComponent("Rigidbody2D");

	//make bullet move upward
	r2d.velocity.y = speed;

}

//function called when object goes out of the screen
function OnBecameInvisible() {
	//destroy the bullet
	Destroy(gameObject);
}