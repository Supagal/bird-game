﻿//public variable that contains the speed of the enemy

public var speed : int = -5;

//function called when the enemy is created

function Start () {

//getrigidbody component

var r2d = GetComponent("Rigidbody2D");

//add a vertical speed to the enemy 

r2d.velocity.y = speed;

//make the enemy rotate on itself

r2d.angularVelocity = Random.Range(-200,200);

}

//Function called when object goes out of camera

function OnBecameInvisible() {

//destroy enemy 

Destroy(gameObject);

}
